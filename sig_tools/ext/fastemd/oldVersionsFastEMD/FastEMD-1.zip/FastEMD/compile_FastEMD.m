mex CXX=g++ CC=g++ LD=g++ -cxx COMPFLAGS='-Wall -O -DNDEBUG' emd_hat_metric_mex.cxx emd_hat_check_and_extract_mex.cxx emd_hat.cpp
mex CXX=g++ CC=g++ LD=g++ -cxx COMPFLAGS='-Wall -O -DNDEBUG' emd_hat_mex.cxx emd_hat_check_and_extract_mex.cxx emd_hat.cpp

